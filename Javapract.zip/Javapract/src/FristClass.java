public class FristClass {

	public static void main(String[] args) {
		System.out.print("first try");	
		SecondClass abc =new SecondClass();
		//abc.test();
		SecondClass.test();
	}
}

