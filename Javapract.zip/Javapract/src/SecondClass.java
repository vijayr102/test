public class SecondClass {

	public static void test() {
		System.out.print("second try");		
	}
}